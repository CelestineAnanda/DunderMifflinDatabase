﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DunderMifflinPaperCo.Models
{
    public class BranchLocation
    {
		public int Id { get; set; }
		public string CityName { get; set; }
		public string Address { get; set; }

		public ICollection<Salesman> Salesmen { get; set; } = new List<Salesman>();
	}
}
