﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DunderMifflinPaperCo.Models
{
    public class DunderMifflinPaperCoContext : DbContext
	{
		public DbSet<BranchLocation> Locations { get; set; }
		public DbSet<Order> Orders { get; set; }
		public DbSet<Salesman> Salesmen { get; set; }
		public DbSet<Customer> Customers { get; set; }



		public DunderMifflinPaperCoContext(DbContextOptions<DunderMifflinPaperCoContext> options)
		: base(options)
		{
			//create but leave empty to call the base class constructor
		}
	}
}
