﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DunderMifflinPaperCo.Models
{
    public class Order
    {
		public int Id { get; set; }
		public int NumberOfReams { get; set; }
		public float Cost { get; set; }
		public DateTime DateOfOrder { get; set; }


		public int SalesmanID { get; set; }
		public Salesman Salesman { get; set; }

		public int CustomerID { get; set; }
		public Customer Customer { get; set; }
	}
}
