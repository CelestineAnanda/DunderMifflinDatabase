﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DunderMifflinPaperCo.Models
{
    public class Salesman
    {
		public int Id { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }

		public int BranchLocationID { get; set; }   //do i need this line?
		public BranchLocation BranchLocation { get; set; }
		public ICollection<Order> Orders { get; set; } = new List<Order>();
	}
}
