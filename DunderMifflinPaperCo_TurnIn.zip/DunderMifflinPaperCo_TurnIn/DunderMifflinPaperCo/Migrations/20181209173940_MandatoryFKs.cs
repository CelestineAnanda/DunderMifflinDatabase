﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace DunderMifflinPaperCo.Migrations
{
    public partial class MandatoryFKs : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Orders_Customers_Customerid",
                table: "Orders");

            migrationBuilder.DropForeignKey(
                name: "FK_Orders_Salesmen_Salesmanid",
                table: "Orders");

            migrationBuilder.DropForeignKey(
                name: "FK_Salesmen_Locations_BranchLocationid",
                table: "Salesmen");

            migrationBuilder.RenameColumn(
                name: "BranchLocationid",
                table: "Salesmen",
                newName: "BranchLocationID");

            migrationBuilder.RenameIndex(
                name: "IX_Salesmen_BranchLocationid",
                table: "Salesmen",
                newName: "IX_Salesmen_BranchLocationID");

            migrationBuilder.RenameColumn(
                name: "Salesmanid",
                table: "Orders",
                newName: "SalesmanID");

            migrationBuilder.RenameColumn(
                name: "Customerid",
                table: "Orders",
                newName: "CustomerID");

            migrationBuilder.RenameIndex(
                name: "IX_Orders_Salesmanid",
                table: "Orders",
                newName: "IX_Orders_SalesmanID");

            migrationBuilder.RenameIndex(
                name: "IX_Orders_Customerid",
                table: "Orders",
                newName: "IX_Orders_CustomerID");

            migrationBuilder.AlterColumn<int>(
                name: "BranchLocationID",
                table: "Salesmen",
                nullable: false,
                oldClrType: typeof(int),
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "SalesmanID",
                table: "Orders",
                nullable: false,
                oldClrType: typeof(int),
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "CustomerID",
                table: "Orders",
                nullable: false,
                oldClrType: typeof(int),
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Orders_Customers_CustomerID",
                table: "Orders",
                column: "CustomerID",
                principalTable: "Customers",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Orders_Salesmen_SalesmanID",
                table: "Orders",
                column: "SalesmanID",
                principalTable: "Salesmen",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Salesmen_Locations_BranchLocationID",
                table: "Salesmen",
                column: "BranchLocationID",
                principalTable: "Locations",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Orders_Customers_CustomerID",
                table: "Orders");

            migrationBuilder.DropForeignKey(
                name: "FK_Orders_Salesmen_SalesmanID",
                table: "Orders");

            migrationBuilder.DropForeignKey(
                name: "FK_Salesmen_Locations_BranchLocationID",
                table: "Salesmen");

            migrationBuilder.RenameColumn(
                name: "BranchLocationID",
                table: "Salesmen",
                newName: "BranchLocationid");

            migrationBuilder.RenameIndex(
                name: "IX_Salesmen_BranchLocationID",
                table: "Salesmen",
                newName: "IX_Salesmen_BranchLocationid");

            migrationBuilder.RenameColumn(
                name: "SalesmanID",
                table: "Orders",
                newName: "Salesmanid");

            migrationBuilder.RenameColumn(
                name: "CustomerID",
                table: "Orders",
                newName: "Customerid");

            migrationBuilder.RenameIndex(
                name: "IX_Orders_SalesmanID",
                table: "Orders",
                newName: "IX_Orders_Salesmanid");

            migrationBuilder.RenameIndex(
                name: "IX_Orders_CustomerID",
                table: "Orders",
                newName: "IX_Orders_Customerid");

            migrationBuilder.AlterColumn<int>(
                name: "BranchLocationid",
                table: "Salesmen",
                nullable: true,
                oldClrType: typeof(int));

            migrationBuilder.AlterColumn<int>(
                name: "Salesmanid",
                table: "Orders",
                nullable: true,
                oldClrType: typeof(int));

            migrationBuilder.AlterColumn<int>(
                name: "Customerid",
                table: "Orders",
                nullable: true,
                oldClrType: typeof(int));

            migrationBuilder.AddForeignKey(
                name: "FK_Orders_Customers_Customerid",
                table: "Orders",
                column: "Customerid",
                principalTable: "Customers",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Orders_Salesmen_Salesmanid",
                table: "Orders",
                column: "Salesmanid",
                principalTable: "Salesmen",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Salesmen_Locations_BranchLocationid",
                table: "Salesmen",
                column: "BranchLocationid",
                principalTable: "Locations",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
