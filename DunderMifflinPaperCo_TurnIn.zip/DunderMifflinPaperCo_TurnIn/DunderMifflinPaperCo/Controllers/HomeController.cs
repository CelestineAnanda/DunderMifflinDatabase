﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DunderMifflinPaperCo.Models;
using Microsoft.EntityFrameworkCore;

namespace DunderMifflinPaperCo.Controllers
{
    public class HomeController : Controller
    {
		private DunderMifflinPaperCoContext context;

		public HomeController(DunderMifflinPaperCoContext c)
		{
			context = c;
		}

		public IActionResult Index()
        {
			var latestOrders = context.Orders
				.Include(sh => sh.Customer)
				.Include(sh => sh.Salesman)
					.ThenInclude(t => t.BranchLocation)
				.Where(sh => sh.DateOfOrder < DateTime.Now)
				.OrderByDescending(sh => sh.DateOfOrder)
					.ThenBy(sh => sh.Salesman.BranchLocation.Address)
					.ThenBy(sh => sh.Salesman.FirstName)
				.Take(10)
				.ToList();

			var futureOrders = context.Orders
				.Include(sh => sh.Customer)
				.Include(sh => sh.Salesman)
					.ThenInclude(t => t.BranchLocation)
				.Where(sh => sh.DateOfOrder > DateTime.Now)
				.OrderByDescending(sh => sh.DateOfOrder)
					.ThenBy(sh => sh.Salesman.BranchLocation.Address)
					.ThenBy(sh => sh.Salesman.FirstName)
				.ToList();

			ViewData["latestOrders"] = latestOrders;
			ViewData["futureOrders"] = futureOrders;

			return View();
		}
		[HttpPost]
		public IActionResult HandlePaperSale(int orderId, int cost)
		{
			Order order = context.Orders.Where(sh => sh.Id == orderId).Single();
			order.Cost = order.NumberOfReams * order.Cost;
			context.SaveChanges();

			return RedirectToAction("Index");
		}

		public IActionResult AddBranchLocation()
		{
			return View(context.Locations.ToList());
		}
		[HttpPost]
		public IActionResult HandleNewBranchLocation(string address, string CityName)
		{
			BranchLocation newBranchLocation = new BranchLocation() { Address = address, CityName = CityName };
			context.Locations.Add(newBranchLocation);
			context.SaveChanges();

			return RedirectToAction("AddBranchLocation");
		}
		public IActionResult AddSalesman()
		{
			var allBranchLocations = context.Locations.Include(BranchLocation => BranchLocation.Salesmen).ToList();
			return View(allBranchLocations);
		}
		[HttpPost]
		public IActionResult HandleNewSalesman(int branchLocationID, string firstName, string lastName)
		{
			BranchLocation existingLocation = context.Locations.Where(Location => Location.Id == branchLocationID).Single();
			Salesman newSalesman = new Salesman() { BranchLocation = existingLocation, FirstName = firstName, LastName = lastName };
			context.Salesmen.Add(newSalesman);
			context.SaveChanges();

			return RedirectToAction("AddSalesman");
		}

		public IActionResult AddCustomer()
		{
			return View(context.Customers.ToList());
		}
		[HttpPost]
		public IActionResult HandleNewCustomer(string FirstName, string LastName, string Address)
		{
			Customer newCustomer = new Customer() { FirstName=FirstName, LastName=LastName, Address=Address };
			context.Customers.Add(newCustomer);
			context.SaveChanges();

			return RedirectToAction("AddCustomer");
		}

		public IActionResult AddOrder()
		{
			List<Object> salesmenNames = new List<Object>();

			var allBranchLocations = context.Locations.Include(branchLocation => branchLocation.Salesmen).ToList();
			foreach (BranchLocation branchLocation in allBranchLocations)
			{
				foreach (Salesman salesman in branchLocation.Salesmen)
				{
					var salesmanInfo = new { Name = $"{salesman.FirstName} at {branchLocation.Address}", SalesmanId = salesman.Id };
					salesmenNames.Add(salesmanInfo);
				}
			}

			ViewData["salesmenNames"] = salesmenNames; //salesmen names
			ViewData["customers"] = context.Customers.OrderByDescending(m => m.FirstName).ThenBy(m => m.LastName).ToList(); //customers

			return View();
		}
		[HttpPost]
		public IActionResult HandleNewOrder(DateTime dateOfOrder, int customerId, int salesmanId, int numberOfReams, float cost)
		{
			Customer customer = context.Customers.Where(m => m.Id == customerId).Single();
			Salesman salesman = context.Salesmen.Where(t => t.Id == salesmanId).Single();

			Order newOrder = new Order() { DateOfOrder = dateOfOrder, Customer = customer, Salesman = salesman, NumberOfReams = numberOfReams, Cost = cost };
			context.Orders.Add(newOrder);
			context.SaveChanges();

			return RedirectToAction("AddOrder");
		}


		public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
